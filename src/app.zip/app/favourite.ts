export class Favourite{
	constructor(public CityId:string,public CityName:string,public DateTime:string,public Humidity:string,public Temperature:string,public pressure:string,public Windspeed:string,public discription:string,public icon:string,public comment:string){}
	
}